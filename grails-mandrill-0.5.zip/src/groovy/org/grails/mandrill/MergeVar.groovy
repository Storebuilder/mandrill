package org.grails.mandrill

class MergeVar {
    String name
    String content
}
