package org.grails.mandrill


class MandrillRecipient {

	String email
	String name

}
