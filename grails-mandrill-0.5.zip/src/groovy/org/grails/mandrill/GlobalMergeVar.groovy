package org.grails.mandrill

class GlobalMergeVar {
    String name
    String content
}
