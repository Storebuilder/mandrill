package org.grails.mandrill

class MandrillAttachment {
    String type
    String name
    String content
}
