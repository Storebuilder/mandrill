package org.grails.mandrill

class RecipientVars {
    String rcpt
    List<MergeVar> vars
}
